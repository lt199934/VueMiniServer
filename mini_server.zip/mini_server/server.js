// npm init
// package name mini_server
// npm i express
// npm i connect-history-api-fallback
//微型服务配置
const express = require('express');
const history = require('connect-history-api-fallback');

//创建应用
const app = express();

//修复history把路由当请求接口的异常
app.use(history());
//应用指向到文件夹
app.use(express.static(__dirname+'/static'));

//启动
app.listen(80,(err)=>{
    if(!err){
        console.log("服务器启动成功");
    }
})